import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import {Provider}  from 'react-redux';
import store from './store' ;


import SearchBar from './components/searchbar.js';
import SearchSummary from './components/searchsummary.js';
import SearchItemDetail from './components/searchitemdetail.js';
import SearchResult from './components/searchresult.js';




function App() {
  return (
    <Provider store={store} >
    <Container fluid='true'>
      <Row>
        <Col > 
          <SearchBar></SearchBar>
        </Col>
      </Row>
      <Row>
        <Col lg={3}> 
          <SearchSummary></SearchSummary>
        </Col>
        <Col lg={6}>
        <SearchResult></SearchResult>
        </Col>
        <Col lg={3}>
          <SearchItemDetail></SearchItemDetail>
          </Col>
      </Row>
    </Container>
    </Provider>
  );
}

export default App;
