import React, {useState} from 'react';
import {connect} from 'react-redux' ;
import './contactsearchresult.scss' ;
import icon from '../assets/Contact_32.png' ;
import {showContactAction} from '../actions/searchAction' ;

function ContactSearchResult(props) {

  const [isHover,setIsHover] = useState(false) ;

  function handleClick() {
    props.dispatch( showContactAction(props.searchresult._source.id) ) ;
  }

  function handleMouseOver(e) {
    setIsHover(true) ;
  }


  function handleMouseLeave() {
    setIsHover(false) ;
  }



  return (
    <div className={`contact ${isHover? "hover":""}`}    onClick={handleClick} onMouseOver={handleMouseOver} onMouseLeave={handleMouseLeave} onClick={handleClick} >
    <span> <img src = {icon} className="search-result-item-icon"></img> 
    <h4>Contact</h4>
    </span>
    <div className="attributeOther" > <label>First Name:</label> {props.searchresult._source.firstname} </div>
      <div className="attributeOther"> <label>Last Name:</label> {props.searchresult._source.lastname} </div>
      <div className="attributeOther"> <label>ID:</label> {props.searchresult._source.id} </div>
      <div className="attributeOther" > <label>City:</label> {props.searchresult._source.city} </div>
    </div>
  );
}

export default  connect() ( ContactSearchResult ) ;