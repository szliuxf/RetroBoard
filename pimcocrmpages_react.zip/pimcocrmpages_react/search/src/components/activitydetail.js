import React from 'react';

function ActivityDetail(props) {

  return (
    <div className="Activity" >
    <h3>Activity Detail</h3>
    <div>  <label>Subject:</label> {props.activityDetail.subject}  </div> 
     <div> <label>Start Time:</label> {props.activityDetail.scheduledstart}</div> 
    <div>  <label>End Time:</label> {props.activityDetail.scheduledend} </div>
    <div>
      <label>Notes:</label>
      <p dangerouslySetInnerHTML={{__html: props.activityDetail.cs_markupnotes}} />
    </div>
    </div>
  );
}

export default  ActivityDetail;