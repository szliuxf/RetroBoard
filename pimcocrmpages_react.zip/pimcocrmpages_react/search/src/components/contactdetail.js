import React from 'react';

function ContactDetail(props) {

    console.log("contact detail") ;
    console.log(props.contactDetail) ;
  return (
    <div className="Contact" >
    <h3>Contact Detail</h3>
    <div>  <label>First Name:</label> {props.contactDetail.firstname}  </div> 
     <div> <label>Last Name:</label> {props.contactDetail.lastname}</div> 
    <div>  <label>Email:</label> {props.contactDetail.emailaddress1} </div>
     <div> <label>Telephone:</label> {props.contactDetail.telephone1} </div>
    <div>  <label>City:</label> {props.contactDetail.address1_city}   </div>  
    <div> <label>Country:</label> {props.contactDetail.address1_country} </div>
    </div>
  );
}

export default  ContactDetail;