import React from 'react';

function RelationshipDetail(props) {

    console.log("relationship detail") ;
    console.log(props.relationshipDetail) ;
  return (
    <div className="Relationship" >
    <h3>Relationship Detail</h3>
    <div>  <label>Name:</label> {props.relationshipDetail.name}  </div> 
    <div>  <label>Email:</label> {props.relationshipDetail.emailaddress1} </div>
     <div> <label>Telephone:</label> {props.relationshipDetail.telephone1} </div>
    <div>  <label>City:</label> {props.relationshipDetail.address1_city}   </div>  
    <div> <label>Country:</label> {props.relationshipDetail.address1_country} </div>
    <div> <label>Last Contacted Date:</label> {props.relationshipDetail.cs_lastcontactdate}</div> 
    <div> <label>Last Contacted By:</label> {props.relationshipDetail.cs_lastcontactedby}</div> 
    </div>
  );
}

export default  RelationshipDetail;