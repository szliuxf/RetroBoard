import React from 'react';
import {connect}  from 'react-redux' ;
import './searchsummary.scss' ;

function SearchSummary(props) {

    
const displaySearchSummary =  () =>  {
    if (props.searchResultSummary != undefined ) {
        return Array.from(props.searchResultSummary.entries()).map( (entity, index) =>  { 
                console.log(entity) ;
                return  <React.Fragment> <div key={index} className="summary-row" >  <label className="summary-label" > {entity[0]} </label> <span >   {entity[1]}  </span> </div> </React.Fragment>
            });

        } ;
}   


if (props.searchResultSummary != undefined) {
return (
        <div className="search-summary" > 
            <div className="search-summary-title"> <h4>Records Type:</h4> </div> 
            {displaySearchSummary()}
        </div>
    );
} else {
    return (
        <div></div>
    )
}


}



const mapStateToProps = state =>  { 
   return    {
    searchResultSummary : state.search.searchResult.summary
    }
}


export default connect( mapStateToProps )(SearchSummary) ;

