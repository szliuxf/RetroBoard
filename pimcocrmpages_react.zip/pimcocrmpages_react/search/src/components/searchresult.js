import React from 'react';
import  ActivitySearchResult  from './activitysearchresult.js' ;
import  ContactSearchResult  from './contactsearchresult.js' ;
import  RelationshipSearchResult  from './relationshipsearchresult.js' ;
import { connect }  from 'react-redux' ;
import './searchresult.scss' ;

function SearchResult(props) {

const displaySearchResult =  () =>  {
    if (props.searchResult != undefined ) {
        return props.searchResult.map( (result, index) =>  { 
            switch (result._index) {
                case "activity" :
                    return <ActivitySearchResult className="search-result-item" key= {index} searchresult={result} ></ActivitySearchResult> ;
                case "relationship" :
                    return <RelationshipSearchResult className="search-result-item" key= {index} searchresult={result}></RelationshipSearchResult> ;
                case "contact" :
                    return <ContactSearchResult className="search-result-item" key= {index} searchresult={result}></ContactSearchResult> ;
                default:
                    return <div></div>
            }

        } );
    }   
}


return (
        <div className="search-result" >   { displaySearchResult()  }           </div>
    );
}


const mapStateToProps = state =>  { 
   return    {
    searchResult : state.search.searchResult.hits
    }
}


export default connect( mapStateToProps )(SearchResult) ;
