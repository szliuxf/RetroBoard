import React, {useState} from 'react';
import {connect} from 'react-redux';
import './activitysearchresult.scss' ;
import {showActivityAction} from '../actions/searchAction' ;
import icon from '../assets/phonecall.png'

function ActivitySearchResult(props) {

  const [isHover, setIsHover] = useState(false); 

  function handleClick() {
    props.dispatch( showActivityAction(props.searchresult._source.id) ) ;
  }

  function handleMouseOver(e) {
    setIsHover(true) ;
  }


  function handleMouseLeave() {
    setIsHover(false) ;
  }



  return (
    <div className={`activity ${isHover? "hover":""}`}    onClick={handleClick} onMouseOver={handleMouseOver} onMouseLeave={handleMouseLeave} >
      <span> <img src = {icon} className="search-result-item-icon"></img> 
      <h4>Activity</h4>
      </span>
      <div> <label>ID:</label> {props.searchresult._source.id} </div>
      <div> <label>Notes:</label> {props.searchresult._source.notes} </div>
    </div>
  );
}

export default connect() ( ActivitySearchResult );