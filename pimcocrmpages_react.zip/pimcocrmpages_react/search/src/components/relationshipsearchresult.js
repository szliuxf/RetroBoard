import React, {useState} from 'react';
import {connect} from 'react-redux';
import './relationshipsearchresult.scss' ;
import icon from '../assets/Account_32.png' ;
import {showRelationshipAction} from '../actions/searchAction' ;

function RelationshipSearchResult(props) {

const [isHover, setIsHover] = useState(false) ;

function handleClick() {
  props.dispatch( showRelationshipAction(props.searchresult._source.id) ) ;
}

function handleMouseOver(e) {
  setIsHover(true) ;
}


function handleMouseLeave() {
  setIsHover(false) ;
}




  return (
    <div className={`relationship ${isHover? "hover":""}`}    onClick={handleClick} onMouseOver={handleMouseOver} onMouseLeave={handleMouseLeave} onClick={handleClick}>
    <span> 
    <img src = {icon} className="search-result-item-icon"></img> 

    <h4>Relationship</h4>
    </span>
      <div> <label>Name:</label> {props.searchresult._source.name} </div>
      <div> <label>ID:</label> {props.searchresult._source.id} </div>
      <div> <label>City:</label> {props.searchresult._source.city} </div>
    </div>
  );
}

export default connect() ( RelationshipSearchResult );