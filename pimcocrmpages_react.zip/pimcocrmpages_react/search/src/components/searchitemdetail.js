import React from 'react';
import {connect} from 'react-redux';
import ContactDetail from './contactdetail' ;
import ActivityDetail from './activitydetail' ;
import RelationshipDetail from './relationshipdetail' ;


function SearchItemDetail(props) {

const displayDetailComponent = () => {
    if (props.searchItemDetail.type == "contact" && props.searchItemDetail.detail.length > 0 ) {
        return <ContactDetail contactDetail={props.searchItemDetail.detail[0]} ></ContactDetail>
    }
    if (props.searchItemDetail.type == "activity" && props.searchItemDetail.detail.length > 0 ) {
        return <ActivityDetail activityDetail={props.searchItemDetail.detail[0]} ></ActivityDetail>
    }
    if (props.searchItemDetail.type == "relationship" && props.searchItemDetail.detail.length > 0 ) {
        return <RelationshipDetail relationshipDetail={props.searchItemDetail.detail[0]} ></RelationshipDetail>
    }

}
  

return (
        <div className="search-item-detail" >  
            {
                displayDetailComponent()
            }
        </div>
    );
}


const mapStateToProps = state =>  { 
    console.log("mapping called") ;
    console.log(state) ;
   return    {
    searchItemDetail : state.search.searchItemDetail
    }
}


export default connect(mapStateToProps) ( SearchItemDetail );
