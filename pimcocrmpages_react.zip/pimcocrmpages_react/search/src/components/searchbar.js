import React, {useState, useEffect } from 'react';
import {connect}  from 'react-redux' ;
import {searchAction} from '../actions/searchAction'
import Select from 'react-select';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import axios from 'axios';

import './searchbar.scss' ;

function SearchBar(props) { 
    const [filter, setFilter] = useState([]);
    const [options, setOptions] = useState([]);
    const [selectedFilter, setSelectedFilter] = useState({});
    const [search, setSearch] = useState("");
   

    useEffect( () => {
      const queryString = `cs_usersearchfilters?$select=cs_filtertext,cs_name&$filter=_cs_userid_value eq 7B32D4EE-5A55-E711-80F2-E0071B716C61` ;
      const url = 'https://pimco-dev.crm.dynamics.com/api/data/v9.1/' ;
      
      axios.get(url + queryString)
      .then( (resp) => {
            console.log(resp) ;
            let loadedOptions = resp.data.value.map( (option) => ( { value: option.cs_filtertext, label:  option.cs_name } ) ) ; 
            setOptions (
                loadedOptions
            )  ;
            setSelectedFilter(
                loadedOptions[0]
            );
        }
      )
    },[]
    ) ;


function  handleFilterChange (filter) {
    console.log(filter) ;
    setFilter(filter) ;
    setSelectedFilter(filter);
    if (search.length >= 3) {
        props.dispatch( searchAction( {search: search, filter:filter}) ) ;
    }

}


function handleSearchChange(event) { 
    setSearch(event.target.value) ;
    if (event.target.value.length >= 3) {
        props.dispatch( searchAction( {search: event.target.value, filter:filter}) ) ;
    }
};


return (
        <div className ="search-container"  > 
            <Container fluid='true' >
            <Row>
                <Col lg={2}> 
                <label className="searchbox"> <h3> CRM Global Search </h3>  </label>  
                </Col>
                <Col lg={4}>
                <input className="searchbox" type="text" placeholder="Search.." name="search" onChange={handleSearchChange} />
                <button type="submit">Search</button> 
                </Col>
                <Col lg={1}>
                 <label> Filtered By:  </label>   
                </Col>
                <Col lg={3}>
                    <Select    isClearable  className="multi-select"  value={selectedFilter}  options={options} onChange={handleFilterChange} />
      
                </Col>
            </Row>
            </Container>
        </div>
    );
}


export default connect() (SearchBar);
