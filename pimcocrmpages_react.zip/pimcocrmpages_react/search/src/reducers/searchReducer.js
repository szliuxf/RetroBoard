import {SEARCH, SEARCH_SUCCESSFUL,CONTACT_ITEM_DETAIL_SUCCESSFUL,ACTIVITY_ITEM_DETAIL_SUCCESSFUL,RELATIONSHIP_ITEM_DETAIL_SUCCESSFUL} from '../actions/types' ;

const initialState = {
    searchResult: [] ,
    searchItemDetail : {},
    searchResultSummary : {}
 }


function searchReducer ( state = initialState, action ) {
    switch (action.type) {
        case SEARCH:
            console.log("reducer called") ;
            return {
                ...state,
                searchQueryString: action.payload 
            }
        case SEARCH_SUCCESSFUL:
                console.log("reducer search sucessful called") ;
                return {
                    ...state,
                    searchResult: action.payload,
                    searchItemDetail: {} 
                }
        case CONTACT_ITEM_DETAIL_SUCCESSFUL:
            console.log("reducer contact detail sucessful called") ;
            return {
                ...state,
                searchItemDetail: action.payload 
            }
        case ACTIVITY_ITEM_DETAIL_SUCCESSFUL:
            console.log("reducer activity detail sucessful called") ;
            return {
                ...state,
                searchItemDetail: action.payload 
            }
        case RELATIONSHIP_ITEM_DETAIL_SUCCESSFUL:
            console.log("reducer relationship detail sucessful called") ;
            return {
                ...state,
                searchItemDetail: action.payload 
            }
            default:
            return state;
    }
}

export default searchReducer;