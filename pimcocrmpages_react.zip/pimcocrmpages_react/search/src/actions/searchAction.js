import {SEARCH, SEARCH_SUCCESSFUL, CONTACT_ITEM_DETAIL_SUCCESSFUL, ACTIVITY_ITEM_DETAIL_SUCCESSFUL, RELATIONSHIP_ITEM_DETAIL_SUCCESSFUL, SEARCH_SUMMARY_SUCCESSFUL} from '../actions/types' ;
import axios from 'axios';


export const searchAction  = (query) => dispatch => {
  
   console.log(query) ;
   const options = {
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Basic ZWxhc3RpYzpkUEJqVkNYRndKM2RvcjZiVG5WMTBGcU0="
         }
      };
    
      let bodyObj =          {
        "query": {
          "bool": {  
            "must" : {
              "multi_match" : {
                "query":      query.search,
                "type":       "most_fields"
              }
            }
            }
          }
        };
      

      if (query.filter ) {
        bodyObj.query.bool.filter = {
          "match_phrase": {
            "tags":  query.filter.value
          }
        }
      }

      const body = JSON.stringify( bodyObj );
      
      
      console.log(body) ;
      const url = 'https://3e578deacb8141d6948038b226cda403.us-west-1.aws.found.io:9243/_search' ;
      
      axios.post(url, body, options)
      .then( (resp) => {
  
        let summary = new Map();
        let hits = resp.data.hits.hits;
        hits.map( (hit) => {
            if (! summary.has(hit._index)) {
              summary.set(hit._index, 1)
            }
            else { 
              summary.set(hit._index, summary.get(hit._index) +1 ) ;
            };
        });

        dispatch( {
                type: SEARCH_SUCCESSFUL,
                payload: {
                    hits:  resp.data.hits.hits,
                    summary: summary
                }}

                ) ;
        
            }
      );


}

export const showContactAction  = (contactId) => dispatch => {
    const options = {
        headers: {
            "Content-Type": "application/json",
            "withCredentials": "true"
         }
      };
    
      const queryString = `contacts?$select=firstname,lastname,emailaddress1,telephone1, address1_city, address1_country,statecode&$filter=cs_id eq ${contactId} and statecode eq 0` ;
      const url = 'https://pimco-dev.crm.dynamics.com/api/data/v9.1/' ;
      
      axios.get(url + queryString,  options)
      .then( (resp) => {
            dispatch( {
                type: CONTACT_ITEM_DETAIL_SUCCESSFUL,
                payload: {
                    type: "contact",
                    detail: resp.data.value
                }}
                ) ;
        }
      )
}

export const showRelationshipAction  = (relationshipId) => dispatch => {
  const options = {
      headers: {
          "Content-Type": "application/json",
          "withCredentials": "true"
       }
    };
  
    const queryString = `accounts?$select=name,emailaddress1,telephone1, address1_city, address1_country,cs_lastcontactedby, cs_lastcontactdate, statecode&$filter=cs_id eq ${relationshipId} and statecode eq 0` ;
    const url = 'https://pimco-dev.crm.dynamics.com/api/data/v9.1/' ;
    
    axios.get(url + queryString,  options)
    .then( (resp) => {
          dispatch( {
              type: RELATIONSHIP_ITEM_DETAIL_SUCCESSFUL,
              payload: {
                  type: "relationship",
                  detail: resp.data.value
              }}
              ) ;
      }
    )
}

export const showActivityAction  = (activityId) => dispatch => {
  const options = {
      headers: {
          "Content-Type": "application/json",
          "withCredentials": "true"
       }
    };
  
    const queryString = `appointments?$select=subject,scheduledstart,scheduledend,cs_markupnotes&$filter=cs_id eq ${activityId} ` ;
    const url = 'https://pimco-dev.crm.dynamics.com/api/data/v9.1/' ;
    
    axios.get(url + queryString,  options)
    .then( (resp) => {
          dispatch( {
              type: ACTIVITY_ITEM_DETAIL_SUCCESSFUL,
              payload: {
                  type: "activity",
                  detail: resp.data.value
              }}
              ) ;
      }
    )
}